@echo off
title Offline Spreadsheet
cd /d "%~dp0"

REM Optional launcher. Only needed if you want the extra-nice
REM "Save As..." window where you pick the folder yourself.
REM (Double-click index.html directly if you don't want this.)

where py >nul 2>nul
if %errorlevel%==0 goto PY
where python >nul 2>nul
if %errorlevel%==0 goto PY

echo.
echo Python is not installed on this PC, so we cannot start the
echo optional local web server. That's fine - just double-click
echo 	index.html
echo Saving will then use the browser's normal "Save to PC" download.
echo.
pause
exit /b

:PY
start "Spreadsheet server" py -m http.server 8765 >nul 2>nul
timeout /t 1 /nobreak >nul
start http://localhost:8765/
exit /b