# Offline Spreadsheet

A spreadsheet program that runs right in your browser, works **completely
offline**, and opens/saves **real Excel files** (.xlsx, .xls, .xlsm, .csv).

I built this because a true offline copy of Excel is hard to come by. This
one never phones home — your data never leaves your machine.

---

## How to use it

1. Open the folder `ExcelOffline`.
2. **Double-click `index.html`** — it opens in your web browser.
3. That's it. There is nothing to install. No internet needed. (The only
   time you'd ever need internet is if the `lib/xlsx.full.min.js` file is
   missing — it's already included so you don't.)

### TIP for the most convenient experience (optional)
If you want an app-like icon instead of opening the file every time:
- Chrome/Edge: open the page, then **⋮ menu → Cast, save, and share →
  Install** ("Install as app") — it appears in your Start menu / taskbar.
  Works fully offline.
- Safari: File → Add to Dock.

---

## Moving to another computer (e.g. a Windows PC)

**Copy the whole `ExcelOffline` folder** (for example by USB stick, e-mail, or
OneDrive/Google Drive). The folder is self-contained — that's everything
you need.

```
ExcelOffline/
  index.html     ← the app; double-click this
  start.bat      ← optional launcher for Windows (only if you want nicer Save As)
  README.md
  lib/
    xlsx.full.min.js   ← Excel library; MUST stay inside lib/ next to index.html
```

On the Windows PC:

1. Copy the whole `ExcelOffline` folder to anywhere you like, e.g.
   `Documents`.
2. **Double-click `index.html`** — it opens in Edge/Chrome. That's it.
   Works with zero internet, nothing to install, nothing to configure.
3. (Optional) Double-click `start.bat` instead — if Python happens to be
   installed it serves the app on `http://localhost:8765/` and you get a
   proper "Save As…" window where you pick the folder and file name. If
   Python is not installed, `start.bat` just tells you to use
   `index.html` — saving still works, it uses the browser's normal
   "Save to PC" download.

> Important: keep `index.html` and the `lib` folder **side by side** in the
> same `ExcelOffline` folder. Only `index.html` and `lib/` are required;
> the `.bat`/`.command`/`.md` files are optional extras.

---

## What you can do

| Task | How |
|---|---|
| **Create** a spreadsheet | Open the app, start typing |
| **Open Excel files** | `Open` button (or `Ctrl+O`) → pick any `.xlsx` / `.xls` / `.xlsm` / `.csv` |
| **Save as Excel** | Type a file name in the box next to the `Save` button, then click `Save` (or press `Ctrl+S`). Downloading a `.xlsx` that opens in real Excel |
| **Export CSV** | `CSV` button |
| **Print** a sheet | `Print` button |
| **Never lose work** | Every change is auto-saved to the browser; a banner offers to restore your last session when you reopen the app |
| **Multiple sheets** | Use the `+` at the bottom-left tabs, double-click a tab to rename |

### Formulas that work
`=SUM(A1:A5)`, `=AVERAGE`, `=MIN`, `=MAX`, `=COUNT`, `=COUNTA`,
`=IF(cond,then,else)`, `=AND`, `=OR`, `=NOT`, `=ABS`, `=ROUND`,
`=ROUNDUP`, `=ROUNDDOWN`, `=INT`, `=FLOOR`, `=CEILING`, `=MOD`,
`=POWER`, `=SQRT`, `=VLOOKUP`, `=HLOOKUP`, `=MATCH`, `=INDEX`,
`=COUNTIF`, `=SUMIF`, `=LEN`, `=LOWER`, `=UPPER`, `=TRIM`, `=PROPER`,
`=LEFT`, `=RIGHT`, `=MID`, `=CONCATENATE`/`=CONCAT`, `=EXACT`,
`=SUBSTITUTE`, `=FIND`, `=ISNUMBER`, `=ISTEXT`, `=ISBLANK`, `=ISERROR`,
`=NOW()`, `=TODAY()`, `=RAND()`, `=PI()`, and normal arithmetic
`+ - * / ^ & %`. References between sheets work too:
`=Sheet2!A1`.

### Formatting
Bold, italic, underline, text colour, fill colour, left/centre/right
alignment, and number formats (Number, Whole number, Percent, Currency,
Date). Select cells first, then click the toolbar buttons.

### Editing tips
- Double-click a cell, or press `F2`, or just start typing to edit.
- `Enter` = down, `Shift+Enter` = up, `Tab` = right, arrows move.
- `Shift+arrows` (or drag with the mouse) selects a range.
- `Delete`/`Backspace` clears the selected cell(s).
- `Ctrl+C` / `Ctrl+V` copy & paste (including formulas).
- `Ctrl+Z` undo, `Ctrl+Y` (or `Ctrl+Shift+Z`) redo.
- Merged cells imported from Excel are shown and navigated correctly, and
  they are preserved when you save.
- Drag the blue fill handle... (fill-handle not included yet — use copy/paste).

---

## Saving keeps your file intact (full fidelity)

When you open a `.xlsx` made in real Excel and click **Save**:

- **Everything you didn't touch stays exactly the same.** Charts, images,
  comments, cell colours, column widths, pivot tables, conditional
  formatting, sheet tabs — the file is patched in place, byte-for-byte,
  and only the cells you edited are rewritten.
- Cells you edit are written out as new Excel cells, so they open cleanly
  in Excel, LibreOffice, Google Sheets, etc.
- If you build a workbook from scratch here (New, or a plain CSV import),
  it saves a normal, clean `.xlsx`.

---

## Files in this folder

```
ExcelOffline/
  index.html              ← the spreadsheet app (double-click this)
  start.bat               ← optional Windows launcher (nicer Save As)
  README.md               ← these instructions
  lib/
    xlsx.full.min.js      ← SheetJS library, does Excel read/write (included)
    ooxml.js              ← keeps your file byte-for-byte intact on save (included)
```

## Known limitations (honest list)

- Real Excel is enormous; this covers the common 95%: formulas, numbers,
  text, dates, percentages, currencies, basic styling, multiple sheets,
  and merged cells.
- Advanced content — **charts, images, comments, pivot tables, macros/VBA,
  conditional formatting** — is *not editable* here, but it is **preserved
  when you save**: open a file that has them, edit a few cells, hit Save,
  and the untouched parts of your file survive perfectly. Macros stay in
  the file but don't run from this app.
- If a file uses a formula we don't know, the cell shows `#NAME?` — the
  original formula is still kept when you re-save.
- Everything is stored on THIS computer only (in the browser). Clearing
  your browser data will delete saved workbooks, so keep a `.xlsx` backup.

## Troubleshooting

- **"Nothing happens when I double-click index.html"** → right-click the
  file → Open With → Chrome / Edge / Safari.
- **File won't open** → make sure `lib/xlsx.full.min.js` is still next to
  `index.html` inside the `ExcelOffline` folder.
- **I lost my data** → check your Downloads folder for the last `.xlsx`
  you saved, then `Open` it back in.