#!/bin/bash
# Optional launcher for macOS (double-click this for the nicer Save-As dialog).
# If you just want to use the app, double-click index.html instead.
cd "$(dirname "$0")"
if command -v python3 >/dev/null 2>&1; then
  python3 -m http.server 8765 >/dev/null 2>&1 &
  sleep 1
  open http://localhost:8765/
else
  echo "Python3 not found - just double-click index.html instead."
  sleep 2
fi